package ex_52;

public class Produto52 {
	public int id;
	public String descricao;
	public double valor;
	public double quantidade;
}
