package ex_51;

public class Cliente51 {
	public int id;
	public String nome;
	public int idade;
	public String email;
}
