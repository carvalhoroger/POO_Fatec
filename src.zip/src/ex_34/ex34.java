package ex_34;

import java.util.Scanner;

public class ex34 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * Exibir a tabuada do número cinco no intervalo de um a dez.
		 */
		
		for(int x = 1; x <= 10; x++) {
			System.out.printf("\n%d X 5 = %d", x, (x*5));
		}
	}

}
