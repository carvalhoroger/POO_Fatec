package ex_54;

public class ContaBanco54 {
	public String agencia;
	public String numero;
	public double saldo;
	
	public ContaBanco54() {
		
	}
	
	public ContaBanco54(String agencia, String numero, double saldo) {
		this.agencia = agencia;
		this.numero = numero;
		this.saldo = saldo;
	}
}