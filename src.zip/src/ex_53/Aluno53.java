package ex_53;

public class Aluno53 {
	public String ra;
	public String nome;
	public String[] materias = new String[6];
	public String periodo;


public Aluno53() {
	
}
}